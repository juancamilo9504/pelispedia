<?php
header("Content-type: text/css");
?>
body {
background-image: linear-gradient(to left, #4e00ca, #b100e7);
margin: 0;
}


.container {
background-color: rgba(0, 0, 0, 0.651);
max-width: 400px;
margin-top: 1.5%;
padding: 20px;
border: 1px solid rgba(0, 0, 0, 0.2);
border-radius: 10px;
}

.form-group {
margin-bottom: 15px;
}

.form-group label {
display: block;
margin-bottom: 5px;
color: #fff;
}

.form-group input {
width: 30%;
padding: 8px;
font-size: 16px;
border: 1px solid rgba(0, 0, 0, 0.2);
border-radius: 4px;
background-color: #0000006b;
color: white;

}

.form-group input[type="checkbox"] {
width: auto;
display: inline-block;
}

.container {
padding-left: 0;
padding-right: 0;
}

footer {
position: fixed;
bottom: 0;
left: 0;
width: 100%;
height: 50px; /* Ajusta la altura según tus necesidades */
background-image: linear-gradient(to top, rgb(0, 0, 0), rgba(0, 0, 0, 0.021) );
color: white;
}

form label{
color: white;
}

form button{
color: #ffffff;
text-align: center;
padding: 0.5%;
text-decoration: none;
background-color: #000000;
border-style: initial;
border: 1px;
border-color: white;
}
form button:hover{
background-color: #ffffff;
color: #000000;
}
div h1{
text-align: center;
color: white;
}
img{
width: 15%;
}

nav {
background-color: #000000;
}

ul {
list-style-type: none;
margin: 0;
padding: 0;
overflow: hidden;
}

li {
float: left;
}

li a {
color: #ffffff;
text-align: center;
padding: 14px 16px;
text-decoration: none;
display: block;
}
li a:hover {
background-color: #ffffff;
color: #000000;
}

.right {
float: right;
}

button a{
text-decoration: none;
color: white;
}
button a:hover{
text-decoration: none;
color: black;
}

.divMovies h3{
border-bottom: double;
border-color: white;
color: white;
}


.divMovies p{
color: white;
}

.divMovies{
align-items: center;
display:inline-block;
top: 0;
left: 0;
background-color: rgba(0, 0, 0, 0.8);
z-index: 3;
transition: background-color 0.3s ease;
margin: 1%;
width: 30%}

.divMovies:hover {
background-color: rgba(0, 0, 0, 0);

}

.divMovies img{
padding: 1%;
margin: 5%;
width: 30%;
align-items: center;
position: relative;
z-index: 1;
}

#menuDesplegable {
width:min-content;
background-color: black;


}
.ul {
background-color: black;
list-style-type: none;
margin: 0;
padding: 0;
float: right;
width: 20%;
color: white;
border-style: none;
z-index: 9999;
position: absolute;
right: 0;
}
.ul:hover {
background-color: #ffffff;
color: #000000;
}