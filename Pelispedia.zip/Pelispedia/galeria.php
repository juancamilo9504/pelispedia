<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/styleGaleria.php">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Movies</title>
</head>

<body>
    <nav>
        <ul>
            <li><a href="#">Acerca de</a></li>
            <li><a href="#">Servicios</a></li>
            <li class="right"><a href="#" onclick="toggleMenu()">Mi cuenta</a></li>
        </ul>
    </nav>
    <div id="menuDesplegable">
                <button class="ul" type="button" onclick="window.location.href='perfil.php'">
                    <h5>Perfil</h5>
                </button><br>
                <button class="ul" type="button" onclick="window.location.href='configuracion.php'">
                    <h5>Configuración</h5>
                </button><br>
                <button class="ul" type="button" onclick="logout()">
                    <h5>Cerrar sesión</h5>
                </button>
            
    </div>

    <script>
        function logout() {
            // Realizar una solicitud al archivo PHP que cierra la sesión
            fetch("logout.php")
                .then(response => response.text())
                .then(data => {
                    // Redireccionar a la página de inicio de sesión
                    window.location.href = "login.php";
                })
                .catch(error => {
                    console.error("Error al cerrar sesión:", error);
                });
        }
    </script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var menu = document.getElementById("menuDesplegable");
        menu.style.display = "none";
    });

    function toggleMenu() {
        var menu = document.getElementById("menuDesplegable");
        if (menu.style.display === "none") {
            menu.style.display = "block";
        } else {
            menu.style.display = "none";
        }
    }
</script>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>
    <?php require "connection.php";
    $peliculas = consultarMovies();
    $directores = consultarDirector();
    for ($i = 0; $i < count($peliculas); $i++) {
        echo "<div class='divMovies'>";
        echo "<center><img src='" . $peliculas[$i]->getPoster() . "' alt='cartelera'>";
        echo "<h3>" . $peliculas[$i]->getTitulo() . "</h3>";
        for ($x = 0; $x < count($directores); $x++) {
            if ($peliculas[$i]->getId_director() == $directores[$x]->getId()) {
                echo "<p>" . $directores[$x]->getNombre() . "</p>";
            }
        }
        echo "<p>Año: " . $peliculas[$i]->getAnio() . "</p><center>";
        echo "</div>";
    }
    ?>
    <br><br><br><br>
    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>