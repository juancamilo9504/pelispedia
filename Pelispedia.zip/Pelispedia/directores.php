<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/items.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Directores</title>
</head>

<body>
    <nav class="nav">
        <ul>
            <li><a href="configuracion.php">Volver</a></li>
        </ul>
    </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>

    <script>
        function llenarCajasTexto(id, nombre, nacionalidad) {
            document.getElementById("id").value = id;
            document.getElementById("nombre").value = nombre;
            document.getElementById("nacionalidad").value = nacionalidad;
        }
    </script>
    <?php
    function tablaDirectores()
    {
        $lista = array();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Error en la conexión: " . $conn->connect_error);
        }

        $result = $conn->query("select * from director");
        if ($result->num_rows > 0) {
            // Imprimir la tabla
            echo "<table>";
            echo "<tr>";
            echo "<th>ID</th>";
            echo "<th>Nombre</th>";
            echo "<th>Nacionalidad</th>";
            echo "</tr>";

            // Iterar sobre los resultados y mostrarlos en la tabla
            while ($row = $result->fetch_assoc()) {
                $id = $row["dir_id"];
                $nombre = $row["dir_nombre"];
                $nacionalidad = $row["dir_nacionalidad"];
                echo "<div class='registro'>";
                echo "<tr onclick='llenarCajasTexto($id, \"$nombre\", \"$nacionalidad\")'>";
                echo "<td>" . $id . "</td>";
                echo "<td>" . $nombre . "</td>";
                echo "<td>" . $nacionalidad . "</td>";
                echo "</tr></div>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron registros.";
        }

        // Cerrar la conexión
        $conn->close();
    }
    tablaDirectores();
    // Agregar un nuevo director
    if (isset($_POST["agregar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $nacionalidad = $_POST['nacionalidad'];

        // Verificar si los datos ya existen en la base de datos
        $query = "SELECT * FROM director WHERE dir_id = '$id' AND dir_nombre = '$nombre' AND dir_nacionalidad = '$nacionalidad'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 0) {
            // Insertar los datos en la base de datos
            $sql = "INSERT INTO `director`(`dir_id`, `dir_nombre`, `dir_nacionalidad`) VALUES ('$id','$nombre','$nacionalidad')";
            mysqli_query($conn, $sql);
            // Redireccionar a la misma página después de la inserción
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            // Datos duplicados, mostrar mensaje de error o realizar otra acción
            echo "Los datos ya existen en la base de datos.";
        }

        $conn->close();
    }


    // Modificar un director existente
    if (isset($_POST["modificar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $nacionalidad = $_POST["nacionalidad"];

        $sql = "UPDATE director SET dir_nombre='$nombre', dir_nacionalidad='$nacionalidad' WHERE dir_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro modificado correctamente.";
            // Redireccionar a la misma página después de la modificación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al modificar el registro: " . $conn->error;
        }
        $conn->close();
    }

    // Eliminar un director
    if (isset($_POST["eliminar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];

        $sql = "DELETE FROM director WHERE dir_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro eliminado correctamente.";
            // Redireccionar a la misma página después de la eliminación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al eliminar el registro: " . $conn->error;
        }
        $conn->close();
    }
    ?>
    <div class="container">
        <center>
            <form class="form-group" method="POST">
                <label>ID:</label><br>
                <input type="text" id="id" name="id"><br><br>
                <label>Nombre:</label><br>
                <input type="text" id="nombre" name="nombre"><br><br>
                <label>Nacionalidad:</label><br>
                <input type="text" id="nacionalidad" name="nacionalidad"><br><br>
                <button type="submit" name="agregar">Agregar</button>
                <button type="submit" name="modificar">Modificar</button>
                <button type="submit" name="eliminar">Eliminar</button>
            </form>
        </center>
    </div>

    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>