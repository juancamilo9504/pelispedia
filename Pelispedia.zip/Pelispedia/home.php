<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/home.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Home</title>
</head>
<body>
    <nav>
        <ul>
          <li><a href="#">Inicio</a></li>
          <li><a href="#">Acerca de</a></li>
          <li><a href="#">Servicios</a></li>
          <li class="right"><a href="login.php">Iniciar Sesión</a></li>
          <li class="right"><a href="signup.php">Registrarse</a></li>
        </ul>
      </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>
    <div class="bgVideo">
        <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <center><iframe width="819" height="500" src="https://www.youtube.com/embed/RtBuQmT6bb4"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen></iframe></center>
                </div>
                <div class="carousel-item">
                    <center><iframe width="819" height="500" src="https://www.youtube.com/embed/qYAETtIIClk"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen></iframe></center>
                </div>
                <div class="carousel-item">
                    <center><iframe width="819" height="500"
                            src="https://www.youtube.com/embed/T5IligQP7Fo?controls=0&amp;start=10"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen></iframe></center>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <article class="gradient-background">
        <div class="bienvenida">
            <h1 class="zoom-text">¡Bienvenidos a Pelispedia, tu fuente de información cinematográfica!</h1><br>
            <p class="zoom-text2"> En Pelispedia, estamos emocionados de compartir contigo todo lo relacionado con el mágico mundo del
                cine.
                Aquí podrás encontrar una amplia gama de películas, desde clásicos inolvidables hasta los últimos
                estrenos.
                Queremos ser tu compañero de confianza para explorar el vasto universo del séptimo arte.

                Sumérgete en nuestras páginas y descubre detalles fascinantes sobre tus películas favoritas. Obtén
                información detallada sobre el reparto, directores, sinopsis y más. Además, te mantendremos al día con
                noticias frescas de la industria cinematográfica para que nunca te pierdas las novedades más
                emocionantes.

                Ya sea que estés buscando una película para disfrutar en familia, quieras explorar nuevos géneros o
                simplemente desees revivir momentos inolvidables del cine, estamos aquí para satisfacer tus necesidades.
                Nuestro objetivo es hacer de tu experiencia en Pelispedia una aventura cinematográfica única y
                memorable.

                Así que, toma asiento, prepárate para sumergirte en el mundo del cine y disfruta de la magia que solo
                las
                películas pueden ofrecer. ¡Bienvenido a Pelispedia, tu destino cinematográfico definitivo!</p>
        </div>
    </article>
    <footer>
        <center><p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p></center>
      </footer>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
    crossorigin="anonymous"></script>

</html>