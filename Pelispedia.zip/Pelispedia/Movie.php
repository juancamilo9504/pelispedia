<?php
class Movie
{
    private $id;
    private $titulo;
    private $id_director;
    private $anio;
    private $poster;
    private $imagen;

    public function __construct($id, $titulo, $id_director, $anio, $poster, $imagen)
    {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->id_director = $id_director;
        $this->anio = $anio;
        $this->poster = $poster;
        $this->imagen = $imagen;
    }

    public function getId()
    {
        return $this->id;
    }
    public function getTitulo()
    {
        return $this->titulo;
    }
    public function setTitulo($valor)
    {
        $this->titulo = $valor;
    }
    public function getId_director()
    {
        return $this->id_director;
    }
    public function setId_director($valor)
    {
        $this->id_director = $valor;
    }
    public function getAnio()
    {
        return $this->anio;
    }
    public function setAnio($valor)
    {
        $this->anio = $valor;
    }
    public function getPoster()
    {
        return $this->poster;
    }
    public function setPoster($valor)
    {
        $this->poster = $valor;
    }
    public function getImagen()
    {
        return $this->imagen;
    }
    public function setImagen($valor)
    {
        $this->imagen = $valor;
    }
}
?>