<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/configuracion.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Configuración</title>
</head>

<body>
    <nav class="nav">
        <ul>
            <li><a href="galeria.php">Volver</a></li>
        </ul>
    </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>
    <center>
        <form class="container">
            <h1>Configuración</h1>
            <br><br>

            <button class="ul" type="button" onclick="window.location.href='directores.php'">
                <h5>Directores</h5>
            </button><br>
            <br><button class="ul" type="button" onclick="window.location.href='peliculas.php'">
                <h5>Peliculas</h5>
            </button><br>
            <br><button class="ul" type="button" onclick="window.location.href='actores.php'">
                <h5>Actores</h5>
            </button><br><br>

        </form>
    </center>
    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>