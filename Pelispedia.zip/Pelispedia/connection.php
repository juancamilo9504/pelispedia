<?php
require 'Movie.php';
require 'Director.php';
require 'Usuario.php';
function consultarMovies()
{   $lista = array();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "galeria";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT * FROM pelicula;");

    // Verificar si se encontraron resultados
    if ($result->num_rows > 0) {
        // Recorrer los resultados obtenidos
        while ($row = $result->fetch_assoc()) {
            // Acceder a los datos de cada fila
            $column1 = $row['peli_id'];
            $column2 = $row['peli_titulo'];
            $column3 = $row['dir_id'];
            $column4 = $row['peli_anio_lanzamiento'];
            $column5 = $row['link_img'];
            $column6 = $row['peli_bg'];
            $movie = new Movie($column1, $column2, $column3, $column4, $column5, $column6);
            array_push($lista, $movie);
        }
    }
    $conn->close();
    return($lista);
}

function consultarDirector()
{   $lista = array();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "galeria";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT * FROM director;");

    // Verificar si se encontraron resultados
    if ($result->num_rows > 0) {
        // Recorrer los resultados obtenidos
        while ($row = $result->fetch_assoc()) {
            // Acceder a los datos de cada fila
            $column1 = $row['dir_id'];
            $column2 = $row['dir_nombre'];
            $column3 = $row['dir_nacionalidad'];
            
            $director = new Director($column1, $column2, $column3);
            array_push($lista, $director);
        }
    }
    $conn->close();
    return($lista);
}

function insertarUsuario($usuario){
    $nombre = $usuario->getNombre();
    $apellido = $usuario->getApellido();
    $email = $usuario->getEmail();
    $Upassword = $usuario->getPassword();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "galeria";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    $conn->query("INSERT INTO `usuarios`
    (`usu_nombre`, `usu_apellidos`, `usu_email`, `usu_password`) 
    VALUES ('".$nombre."','".$apellido."','".$email."','".$Upassword."')");}

function login()
{
    // Establecer la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "galeria";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Comprobar la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Procesar los datos del formulario de inicio de sesión
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $correo = $_POST['correo'];
        $contrasena = $_POST['contrasena'];

        // Consultar la base de datos para verificar las credenciales
        $sql = "SELECT * FROM usuarios WHERE usu_email = '$correo' AND usu_password = '$contrasena'";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            // Inicio de sesión exitoso
            session_start();
            $_SESSION['correo'] = $correo;
            header("Location: galeria.php"); // Página de inicio de sesión exitoso
        } else {
            // Error en las credenciales
            $error = "Credenciales inválidas. Inténtalo de nuevo.";
            return $error;
        }
    }

    $conn->close();
}





?>