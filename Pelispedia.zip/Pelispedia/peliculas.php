<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/items.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Peliculas</title>
</head>

<body>
    <nav class="nav">
        <ul>
            <li><a href="configuracion.php">Volver</a></li>
        </ul>
    </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>

    <script>
        function llenarCajasTexto(id, titulo, director, anio, imagen) {
            document.getElementById("id").value = id;
            document.getElementById("titulo").value = titulo;
            document.getElementById("director").value = director;
            document.getElementById("anio").value = anio;
            document.getElementById("imagen").value = imagen;
        }
    </script>
    <?php
    ob_start();
    function tablaPeliculas()
    {
        $lista = array();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Error en la conexión: " . $conn->connect_error);
        }

        $result = $conn->query("SELECT p.peli_id, p.peli_titulo, p.dir_id, d.dir_nombre, p.peli_anio_lanzamiento, p.link_img FROM pelicula p JOIN director d ON p.dir_id = d.dir_id ORDER BY p.peli_id");
        if ($result->num_rows > 0) {
            // Imprimir la tabla
            echo "<table>";
            echo "<tr>";
            echo "<th>ID</th>";
            echo "<th>Título</th>";
            echo "<th>Id director</th>";
            echo "<th>Director</th>";
            echo "<th>Año de lanzamiento</th>";
            echo "<th>Imagen</th>";
            echo "</tr>";

            // Iterar sobre los resultados y mostrarlos en la tabla
            while ($row = $result->fetch_assoc()) {
                $id = $row["peli_id"];
                $titulo = $row["peli_titulo"];
                $directorID = $row["dir_id"];
                $director = $row["dir_nombre"];
                $anio = $row["peli_anio_lanzamiento"];
                $imagen = $row["link_img"];
                echo "<div class='registro'>";
                echo "<tr onclick='llenarCajasTexto($id, \"$titulo\", \"$directorID\", $anio, \"$imagen\")'>";
                echo "<td>" . $id . "</td>";
                echo "<td>" . $titulo . "</td>";
                echo "<td>" . $directorID . "</td>";
                echo "<td>" . $director . "</td>";
                echo "<td>" . $anio . "</td>";
                echo "<td>" . $imagen . "</td>";
                echo "</tr></div>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron registros.";
        }

        // Cerrar la conexión
        $conn->close();
    }
    tablaPeliculas();
    // Agregar una nueva película
    if (isset($_POST["agregar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        $id = $_POST['id'];
        $titulo = $_POST['titulo'];
        $director = $_POST['director'];
        $anio = $_POST['anio'];
        $imagen = $_POST['imagen'];

        // Verificar si los datos ya existen en la base de datos
        $query = "SELECT * FROM pelicula WHERE peli_id = '$id' AND peli_titulo = '$titulo' AND dir_id = '$director' AND peli_anio_lanzamiento = '$anio' AND link_img = '$imagen'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 0) {
            // Insertar los datos en la base de datos
            $sql = "INSERT INTO pelicula (peli_id, peli_titulo, dir_id, peli_anio_lanzamiento, link_img) VALUES ('$id','$titulo','$director','$anio','$imagen')";
            mysqli_query($conn, $sql);
            // Redireccionar a la misma página después de la inserción
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            // Datos duplicados, mostrar mensaje de error o realizar otra acción
            echo "Los datos ya existen en la base de datos.";
        }

        $conn->close();
    }


    // Modificar una película existente
    if (isset($_POST["modificar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];
        $titulo = $_POST["titulo"];
        $director = $_POST["director"];
        $anio = $_POST["anio"];
        $imagen = $_POST["imagen"];

        $sql = "UPDATE pelicula SET peli_titulo='$titulo', dir_id='$director', peli_anio_lanzamiento='$anio', link_img='$imagen' WHERE peli_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro modificado correctamente.";
            // Redireccionar a la misma página después de la modificación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al modificar el registro: " . $conn->error;
        }
        $conn->close();
    }

    // Eliminar una película
    if (isset($_POST["eliminar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];

        $sql = "DELETE FROM pelicula WHERE peli_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro eliminado correctamente.";
            // Redireccionar a la misma página después de la eliminación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al eliminar el registro: " . $conn->error;
        }
        $conn->close();
    }
    ob_end_flush();
    ?>
    <div class="container">
        <center>
            <form class="form-group" method="POST">
                <label>ID:</label><br>
                <input type="text" id="id" name="id"><br><br>
                <label>Título:</label><br>
                <input type="text" id="titulo" name="titulo"><br><br>
                <label>Director:</label><br>
                <input type="text" id="director" name="director"><br><br>
                <label>Año de lanzamiento:</label><br>
                <input type="text" id="anio" name="anio"><br><br>
                <label>Imagen:</label><br>
                <input type="text" id="imagen" name="imagen"><br><br>
                <button type="submit" name="agregar">Agregar</button>
                <button type="submit" name="modificar">Modificar</button>
                <button type="submit" name="eliminar">Eliminar</button>
            </form>
        </center>
    </div>

    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>
