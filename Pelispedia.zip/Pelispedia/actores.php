<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/items.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Actores</title>
</head>

<body>
    <nav class="nav">
        <ul>
            <li><a href="configuracion.php">Volver</a></li>
        </ul>
    </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>

    <script>
        function llenarCajasTexto(id, nombre, apellido) {
            document.getElementById("id").value = id;
            document.getElementById("nombre").value = nombre;
            document.getElementById("apellido").value = apellido;
        }
    </script>
    <?php
    function tablaActores()
    {
        $lista = array();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Error en la conexión: " . $conn->connect_error);
        }

        $result = $conn->query("SELECT * FROM actor");
        if ($result->num_rows > 0) {
            // Imprimir la tabla
            echo "<table>";
            echo "<tr>";
            echo "<th>ID</th>";
            echo "<th>Nombre</th>";
            echo "<th>Apellido</th>";
            echo "</tr>";

            // Iterar sobre los resultados y mostrarlos en la tabla
            while ($row = $result->fetch_assoc()) {
                $id = $row["act_id"];
                $nombre = $row["act_nombre"];
                $apellido = $row["act_apellido"];
                echo "<div class='registro'>";
                echo "<tr onclick='llenarCajasTexto($id, \"$nombre\", \"$apellido\")'>";
                echo "<td>" . $id . "</td>";
                echo "<td>" . $nombre . "</td>";
                echo "<td>" . $apellido . "</td>";
                echo "</tr></div>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron registros.";
        }

        // Cerrar la conexión
        $conn->close();
    }
    tablaActores();
    // Agregar un nuevo actor
    if (isset($_POST["agregar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);

        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];

        // Verificar si los datos ya existen en la base de datos
        $query = "SELECT * FROM actor WHERE act_id = '$id' AND act_nombre = '$nombre' AND act_apellido = '$apellido'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 0) {
            // Insertar los datos en la base de datos
            $sql = "INSERT INTO `actor`(`act_id`, `act_nombre`, `act_apellido`) VALUES ('$id','$nombre','$apellido')";
            mysqli_query($conn, $sql);
            // Redireccionar a la misma página después de la inserción
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            // Datos duplicados, mostrar mensaje de error o realizar otra acción
            echo "Los datos ya existen en la base de datos.";
        }

        $conn->close();
    }


    // Modificar un actor existente
    if (isset($_POST["modificar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];

        $sql = "UPDATE actor SET act_nombre='$nombre', act_apellido='$apellido' WHERE act_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro modificado correctamente.";
            // Redireccionar a la misma página después de la modificación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al modificar el registro: " . $conn->error;
        }
        $conn->close();
    }

    // Eliminar un actor
    if (isset($_POST["eliminar"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "galeria";

        // Crear la conexión
        $conn = new mysqli($servername, $username, $password, $database);
        $id = $_POST["id"];

        $sql = "DELETE FROM actor WHERE act_id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Registro eliminado correctamente.";
            // Redireccionar a la misma página después de la eliminación
            header("Location: ".$_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error al eliminar el registro: " . $conn->error;
        }
        $conn->close();
    }
    ?>
    <div class="container">
        <center>
            <form class="form-group" method="POST">
                <label>ID:</label><br>
                <input type="text" id="id" name="id"><br><br>
                <label>Nombre:</label><br>
                <input type="text" id="nombre" name="nombre"><br><br>
                <label>Apellido:</label><br>
                <input type="text" id="apellido" name="apellido"><br><br>
                <button type="submit" name="agregar">Agregar</button>
                <button type="submit" name="modificar">Modificar</button>
                <button type="submit" name="eliminar">Eliminar</button>
            </form>
        </center>
    </div>

    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>
