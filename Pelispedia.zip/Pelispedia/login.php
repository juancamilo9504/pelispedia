<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar los valores del formulario
    $email = $_POST["email"];
    $password = $_POST["password"];
    $servername = "localhost";  // Nombre del servidor MySQL (por lo general, localhost)
    $username = "root";  // Nombre de usuario de MySQL
    $dbpassword = "";  // Contraseña de MySQL
    $dbname = "galeria";  // Nombre de la base de datos que creaste

    // Crear conexión
    $conn = new mysqli($servername, $username, $dbpassword, $dbname);

    // Verificar si hubo un error en la conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Preparar la consulta SQL
    $sql = "SELECT * FROM `usuarios` WHERE `usu_email` = '$email' AND `usu_password` = '$password'";

    // Ejecutar la consulta SQL
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Inicio de sesión exitoso
        $_SESSION["email"] = $email;
        header("Location: galeria.php");
        exit();
    } else {
        // Credenciales inválidas
        $error = "Correo electrónico o contraseña incorrectos";
    }


    // Cerrar la conexión
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="Estilos/login.css">
  <link rel="icon" type="image/png" href="Images/7671093.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <title>Pelispedia | Login</title>
</head>

<body>
  <nav>
    <ul>
      <li><a href="home.php">Inicio</a></li>
      <li><a href="#">Acerca de</a></li>
      <li><a href="#">Servicios</a></li>
      <li class="right"><a href="signup.php">Registrarse</a></li>
    </ul>
  </nav>
  <center><img src="Images/Pelispedia.png" alt="logo"></center>
  <div class="container">
    <h1>Inicio de sesión</h1><br>
    <form method="post">
      <center>
        <div class="form-group">
          <label>Correo electrónico:</label>
          <input type="text" name="email" required>
        </div>
      </center>
      <center>
        <div class="form-group">
          <label>Contraseña:</label>
          <input type="password" name="password" required><br><br>
          <button type="submit">Iniciar sesión</button>
        </div>
      </center><br>
    </form>
    <?php if (isset($error))
      echo $error; ?>
  </div>
  <footer>
    <center>
      <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
    </center>
  </footer>
</body>

</html>