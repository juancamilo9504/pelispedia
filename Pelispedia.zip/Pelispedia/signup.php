

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/login.css">
    <link rel="icon" type="image/png" href="Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Sign Up</title>
</head>

<body>
    <nav>
        <ul>
            <li><a href="home.php">Inicio</a></li>
            <li><a href="#">Acerca de</a></li>
            <li><a href="#">Servicios</a></li>
            <li class="right"><a href="login.php">Iniciar Sesión</a></li>
        </ul>
    </nav>
    <center><img src="Images/Pelispedia.png" alt="logo"></center>
    <div class="container">
        <h1>Registro de usuario</h1><br>
        <form method="POST">
            <center>
                <div class="form-group">
                    <label for="name">Nombre</label>
                    <input type="text" name="name" placeholder="Ingresa tu nombre">
                </div>
            </center><br>
            <center>
                <div class="form-group">
                    <label for="lastName">Apellidos</label>
                    <input type="text" name="lastName" placeholder="Ingresa tus apellidos">
                </div>
            </center><br>
            <center>
                <div class="form-group">
                    <label for="email">Correo electrónico</label>
                    <input type="email" name="email" placeholder="Ingresa tu correo electrónico">
                </div>
            </center><br>
            <center>
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" name="password" placeholder="Ingresa tu contraseña">
                </div>
            </center><br>
            <center><button type="submit">Registrarse</button></center>
        </form>
    </div>
    <br><br><br><br><br>
    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>
<?php 
require 'connection.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['name'];
    $apellido = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    try{
        $usuario1 = new Usuario($nombre, $apellido, $email, $password);
        insertarUsuario($usuario1);
    }
    catch(Exception $e){
        echo "<p>Ya hay un usuario registrado con ese email</p>";
    }
}
?>